---
title: "Posting Updates"
description: "Guide on Project Updates"
---

Founders are responsible for regularly updating investors on the project’s progress via Nostr.

### Founder’s Responsibility

* Use the project’s private key to post updates directly through a Nostr client.
* Maintain transparency and ensure regular communication with investors to keep them informed of all developments.
